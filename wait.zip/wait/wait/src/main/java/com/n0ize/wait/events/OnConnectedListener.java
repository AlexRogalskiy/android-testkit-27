package com.n0ize.wait.events;

/**
 * n0ise on 3/6/2017.
 */
public interface OnConnectedListener {
    void OnConnected();
}
