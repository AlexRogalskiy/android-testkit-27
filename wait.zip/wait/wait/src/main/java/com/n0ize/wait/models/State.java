package com.n0ize.wait.models;

/**
 * n0ise on 3/2/2017.
 */
public enum State {
    NONE,
    EMPTY,
    LOADING,
    WORKING,
    RETRY
}
