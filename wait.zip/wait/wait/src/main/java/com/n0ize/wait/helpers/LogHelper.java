package com.n0ize.wait.helpers;

/**
 * n0ise on 3/5/2017.
 */
public class LogHelper {
    public static String tag = "com.n0ize.wait";
}
