package com.n0ize.demo;

import android.app.Application;

/**
 * n0ise on 3/5/2017.
 */
public class App extends Application {
    @Override
    public void onCreate() {
        super.onCreate();

//        final Typeface typeface = Typeface.createFromAsset(getAssets(), "fonts/IRANSansMobile.ttf");
//
//        WaitConfiguration config = new WaitConfiguration.Builder()
//                .setEmptyMessage("Nothing to show.")
//                .setRetryMessage("Check your connection and try again.")
//                .setRetryButtonText("retry")
//                .setTypeFace(typeface)
//                .setLoadingViewRes(R.layout.loading_layout)
//                .setWorkingViewRes(R.layout.working_layout)
//                .setRetryViewRes(R.layout.retry_layout)
//                .build();
//
//        Wait.setConfiguration(config);
    }


}
